package code;

public interface ICalculatorDouble {
	double add(double a, double b);
	double sub(double a, double b);
	double multi(double a, double b);
	double div(double a, double b);
	boolean greater(double a, double b);
}
