package code;

public interface IPsikus {
	   Integer cyfrokrad(Integer liczba);
	   Integer hultajchochla(Integer liczba) throws NieduanyPsikusException;
	   Integer nieksztaltek(Integer liczba);
	}