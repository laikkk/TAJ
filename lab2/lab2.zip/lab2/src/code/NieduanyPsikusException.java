package code;

public class NieduanyPsikusException extends Exception {

}
